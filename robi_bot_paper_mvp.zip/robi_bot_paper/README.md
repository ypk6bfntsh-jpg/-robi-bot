# ROBI BOT — Paper Trading MVP

هذا مشروع بداية لنسخة آمنة من الفكرة الظاهرة في الفيديو.

## ماذا يفعل؟
- Dashboard شبيه بفكرة الفيديو.
- ثلاث وحدات: SCOUT / RISK / EXEC.
- إشارات سوق عشوائية للتجربة فقط.
- إدارة مخاطرة بسيطة.
- سجل صفقات.
- P&L و Win Rate.
- لا يوجد اتصال بمحفظة.
- لا يوجد Private Key.
- لا يوجد تنفيذ on-chain.
- لا يوجد تداول حقيقي.

## التشغيل

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

ثم افتح الرابط الذي يظهر في الطرفية.

## المرحلة التالية

نستبدل البيانات العشوائية تدريجيًا بـ:
1. بيانات سوق حقيقية للقراءة فقط.
2. فلتر سيولة وحجم.
3. Backtesting.
4. Paper trading مستمر.
5. سجل قابل للتدقيق.
6. وبعد اختبار مستقل، يمكن دراسة التنفيذ الحقيقي بشكل منفصل.

لا تضع Seed Phrase أو Private Key داخل هذا المشروع.
